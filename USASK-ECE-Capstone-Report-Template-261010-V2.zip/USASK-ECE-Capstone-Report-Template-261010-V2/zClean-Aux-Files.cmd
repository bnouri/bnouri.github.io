@echo off

:: TeX:------
del *.out *.log *.aux *.blg *.bbl *.toc *.dvi *.bak *.prj.bak 
del *.lot *.lof *.tps *.synctex *.tmp *.tps  *.pdfsync
del *.ps *.undo *.txt *.tex~ *.tex.backup 

:: Beamer:------
del *.nav *.snm *.bcf *.fls *.fdb_latexmk *.xdv *.run.* *.md
