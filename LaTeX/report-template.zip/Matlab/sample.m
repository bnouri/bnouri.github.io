function xsavetxt(filename, mat)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m n]=size(mat);
fid=fopen(filename, 'at');
fprintf(fid,'%% %s\n', filename);
fprintf(fid,'%% MNA_Size\t Time(sec)\t Nr_it \n');
for i=1:m
    for j=1:n
        fprintf(fid, '%g  ',mat(i,j));
        if j==n
            fprintf(fid, '\n');
        end             
    end
end
fclose(fid);
end %func
